﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PiñateriaMandM.Entity;

namespace PiñateriaMandM.DataAccess
{
    public class PurchaseDetailDAL:Connection
    {
        private static PurchaseDetailDAL _instance;
        public static PurchaseDetailDAL Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new PurchaseDetailDAL();
                return _instance;
            }
        }

        public bool Insert(PurchaseDetail entity)
        {
            bool result = false;

            using (SqlConnection conn = new SqlConnection(_cadena))
            {
                using (SqlCommand cmd = new SqlCommand("spInsertPurchaseDetail", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@PurchaseId", entity.PurchaseId);
                    cmd.Parameters.AddWithValue("@ProductId", entity.ProductsId);
                    cmd.Parameters.AddWithValue("@Quantity", entity.Quantity);
                    cmd.Parameters.AddWithValue("@UnitPrice", entity.PricePerUnit);

                    conn.Open();
                    result = cmd.ExecuteNonQuery() > 0;
                }
            }

            return result;
        }

        public bool Update(PurchaseDetail entity)
        {
            bool result = false;

            using (SqlConnection conn = new SqlConnection(_cadena))
            {
                using (SqlCommand cmd = new SqlCommand("spUpdatePurchaseDetail", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@PurchaseDetailId", entity.PurchaseDetailId);
                    cmd.Parameters.AddWithValue("@PurchaseId", entity.PurchaseId);
                    cmd.Parameters.AddWithValue("@ProductId", entity.ProductsId);
                    cmd.Parameters.AddWithValue("@Quantity", entity.Quantity);
                    cmd.Parameters.AddWithValue("@UnitPrice", entity.PricePerUnit);

                    conn.Open();
                    result = cmd.ExecuteNonQuery() > 0;
                }
            }

            return result;
        }

        public bool Delete(int id)
        {
            bool result = false;

            using (SqlConnection conn = new SqlConnection(_cadena))
            {
                using (SqlCommand cmd = new SqlCommand("spDeletePurchaseDetail", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@PurchaseDetailId", id);

                    conn.Open();
                    result = cmd.ExecuteNonQuery() > 0;
                }
            }

            return result;
        }

        public List<PurchaseDetail> SelectAll()
        {
            List<PurchaseDetail> result = null;

            using (SqlConnection conn = new SqlConnection(_cadena))
            {
                using (SqlCommand cmd = new SqlCommand("spPurchaseDetailSelectAll", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    conn.Open();
                    using (SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.SingleResult))
                    {
                        if (dr != null)
                        {
                            result = new List<PurchaseDetail>();

                            while (dr.Read())
                            {
                                PurchaseDetail entity = new PurchaseDetail()
                                {
                                    PurchaseDetailId = dr.GetInt32(0),
                                    PurchaseId = dr.GetInt32(1),
                                    ProductsId = dr.GetInt32(2),
                                    Quantity = dr.GetInt32(3),
                                    PricePerUnit = dr.GetDecimal(4)
                                };

                                result.Add(entity);
                            }
                        }
                    }
                }
            }

            return result;
        }

        public PurchaseDetail SelectById(int id)
        {
            PurchaseDetail result = null;

            using (SqlConnection conn = new SqlConnection(_cadena))
            {
                using (SqlCommand cmd = new SqlCommand("spPurchaseDetailSelectById", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@PurchaseDetailId", id);

                    conn.Open();
                    using (SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.SingleResult))
                    {
                        if (dr != null)
                        {
                            while (dr.Read())
                            {
                                result = new PurchaseDetail()
                                {
                                    PurchaseDetailId = dr.GetInt32(0),
                                    PurchaseId = dr.GetInt32(1),
                                    ProductsId = dr.GetInt32(2),
                                    Quantity = dr.GetInt32(3),
                                    PricePerUnit = dr.GetDecimal(4)
                                };
                            }
                        }
                    }
                }
            }

            return result;
        }
    }
}
