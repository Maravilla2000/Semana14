﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PiñateriaMandM.Entity;


namespace PiñateriaMandM.DataAccess
{
    public class SaleDetailDAL:Connection
    {
        private static SaleDetailDAL _instance;
        public static SaleDetailDAL Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new SaleDetailDAL();
                return _instance;
            }
        }

        public bool Insert(SaleDetail entity)
        {
            bool result = false;

            using (SqlConnection conn = new SqlConnection(_cadena))
            {
                using (SqlCommand cmd = new SqlCommand("spInsertSaleDetail", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@SaleId", entity.SaleId);
                    cmd.Parameters.AddWithValue("@ProductId", entity.ProductId);
                    cmd.Parameters.AddWithValue("@Quantity", entity.Quantity);
                    cmd.Parameters.AddWithValue("@UnitPrice", entity.PricePerUnit);

                    conn.Open();
                    result = cmd.ExecuteNonQuery() > 0;
                }
            }

            return result;
        }

        public bool Update(SaleDetail entity)
        {
            bool result = false;

            using (SqlConnection conn = new SqlConnection(_cadena))
            {
                using (SqlCommand cmd = new SqlCommand("spUpdateSaleDetail", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@SaleDetailId", entity.SaleDetailId);
                    cmd.Parameters.AddWithValue("@SaleId", entity.SaleId);
                    cmd.Parameters.AddWithValue("@ProductId", entity.ProductId);
                    cmd.Parameters.AddWithValue("@Quantity", entity.Quantity);
                    cmd.Parameters.AddWithValue("@UnitPrice", entity.PricePerUnit);

                    conn.Open();
                    result = cmd.ExecuteNonQuery() > 0;
                }
            }

            return result;
        }

        public bool Delete(int id)
        {
            bool result = false;

            using (SqlConnection conn = new SqlConnection(_cadena))
            {
                using (SqlCommand cmd = new SqlCommand("spDeleteSaleDetail", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@SaleDetailId", id);

                    conn.Open();
                    result = cmd.ExecuteNonQuery() > 0;
                }
            }

            return result;
        }

        public List<SaleDetail> SelectAll()
        {
            List<SaleDetail> result = null;

            using (SqlConnection conn = new SqlConnection(_cadena))
            {
                using (SqlCommand cmd = new SqlCommand("spSaleDetailSelectAll", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    conn.Open();
                    using (SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.SingleResult))
                    {
                        if (dr != null)
                        {
                            result = new List<SaleDetail>();

                            while (dr.Read())
                            {
                                SaleDetail entity = new SaleDetail()
                                {
                                    SaleDetailId = dr.GetInt32(0),
                                    SaleId = dr.GetInt32(1),
                                    ProductId = dr.GetInt32(2),
                                    Quantity = dr.GetInt32(3),
                                    PricePerUnit = dr.GetDecimal(4)
                                };

                                result.Add(entity);
                            }
                        }
                    }
                }
            }

            return result;
        }

        public SaleDetail SelectById(int id)
        {
            SaleDetail result = null;

            using (SqlConnection conn = new SqlConnection(_cadena))
            {
                using (SqlCommand cmd = new SqlCommand("spSaleDetailSelectById", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@SaleDetailId", id);

                    conn.Open();
                    using (SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.SingleResult))
                    {
                        if (dr != null)
                        {
                            while (dr.Read())
                            {
                                result = new SaleDetail()
                                {
                                    SaleDetailId = dr.GetInt32(0),
                                    SaleId = dr.GetInt32(1),
                                    ProductId = dr.GetInt32(2),
                                    Quantity = dr.GetInt32(3),
                                    PricePerUnit = dr.GetDecimal(4)
                                };
                            }
                        }
                    }
                }
            }

            return result;
        }
    }
}
