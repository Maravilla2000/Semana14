﻿using PiñateriaMandM.DataAccess;
using PiñateriaMandM.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PiñateriaMandM.BusinessLogic
{
    public class SaleDetailBL
    {
        private static SaleDetailBL _instance;
        public static SaleDetailBL Instance
        {
            get
            {
                return _instance ?? (_instance = new SaleDetailBL());
            }
        }

        public bool Insert(SaleDetail entity)
        {
            bool result = false;
            try
            {
                result = SaleDetailDAL.Instance.Insert(entity);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return result;
        }

        public bool Update(SaleDetail entity)
        {
            bool result = false;
            try
            {
                result = SaleDetailDAL.Instance.Update(entity);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return result;
        }

        public bool Delete(int id)
        {
            bool result = false;
            try
            {
                result = SaleDetailDAL.Instance.Delete(id);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return result;
        }

        public List<SaleDetail> SelectAll()
        {
            List<SaleDetail> result = null;
            try
            {
                result = SaleDetailDAL.Instance.SelectAll();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return result;
        }

        public SaleDetail SelectById(int id)
        {
            SaleDetail result = null;
            try
            {
                result = SaleDetailDAL.Instance.SelectById(id);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return result;
        }
    }

}
