﻿using PiñateriaMandM.DataAccess;
using PiñateriaMandM.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PiñateriaMandM.BusinessLogic
{
    public class UserRoleBL
    {
        private static UserRoleBL _instance;
        public static UserRoleBL Instance
        {
            get
            {
                return _instance ?? (_instance = new UserRoleBL());
            }
        }

        public bool Insert(UserRole entity)
        {
            bool result = false;
            try
            {
                result = UserRoleDAL.Instance.Insert(entity);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return result;
        }

        public bool Update(UserRole entity)
        {
            bool result = false;
            try
            {
                result = UserRoleDAL.Instance.Update(entity);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return result;
        }

        public bool Delete(int id)
        {
            bool result = false;
            try
            {
                result = UserRoleDAL.Instance.Delete(id);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return result;
        }

        public List<UserRole> SelectAll()
        {
            List<UserRole> result = null;
            try
            {
                result = UserRoleDAL.Instance.SelectAll();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return result;
        }

        public UserRole SelectById(int id)
        {
            UserRole result = null;
            try
            {
                result = UserRoleDAL.Instance.SelectById(id);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return result;
        }
    }

}
