﻿using PiñateriaMandM.DataAccess;
using PiñateriaMandM.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PiñateriaMandM.BusinessLogic
{
    public class PositionBL
    {
        private static PositionBL _instance;
        public static PositionBL Instance
        {
            get
            {
                return _instance ?? (_instance = new PositionBL());
            }
        }

        public bool Insert(Position entity)
        {
            bool result = false;
            try
            {
                result = PositionDAL.Instance.Insert(entity);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return result;
        }

        public bool Update(Position entity)
        {
            bool result = false;
            try
            {
                result = PositionDAL.Instance.Update(entity);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return result;
        }

        public bool Delete(int id)
        {
            bool result = false;
            try
            {
                result = PositionDAL.Instance.Delete(id);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return result;
        }

        public List<Position> SelectAll()
        {
            List<Position> result = null;
            try
            {
                result = PositionDAL.Instance.SelectAll();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return result;
        }

        public Position SelectById(int id)
        {
            Position result = null;
            try
            {
                result = PositionDAL.Instance.SelectById(id);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return result;
        }
    }

}
