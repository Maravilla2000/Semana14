﻿using PiñateriaMandM.DataAccess;
using PiñateriaMandM.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PiñateriaMandM.BusinessLogic
{
    public class SaleBL
    {
        private static SaleBL _instance;
        public static SaleBL Instance
        {
            get
            {
                return _instance ?? (_instance = new SaleBL());
            }
        }

        public bool Insert(Sale entity)
        {
            bool result = false;
            try
            {
                result = SaleDAL.Instance.Insert(entity);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return result;
        }

        public bool Update(Sale entity)
        {
            bool result = false;
            try
            {
                result = SaleDAL.Instance.Update(entity);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return result;
        }

        public bool Delete(int id)
        {
            bool result = false;
            try
            {
                result = SaleDAL.Instance.Delete(id);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return result;
        }

        public List<Sale> SelectAll()
        {
            List<Sale> result = null;
            try
            {
                result = SaleDAL.Instance.SelectAll();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return result;
        }

        public Sale SelectById(int id)
        {
            Sale result = null;
            try
            {
                result = SaleDAL.Instance.SelectById(id);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return result;
        }
    }

}
